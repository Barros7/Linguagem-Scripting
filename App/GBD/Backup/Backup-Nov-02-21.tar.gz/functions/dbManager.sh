#!/bin/bash

function dbManager(){
    
}

dbManager ""