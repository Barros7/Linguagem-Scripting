#!/bin/bash

function updatePrice(){
    
}

updatePrice ""