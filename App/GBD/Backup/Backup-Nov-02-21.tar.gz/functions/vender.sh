#!/bin/bash

function vender(){


    
}

vender ""